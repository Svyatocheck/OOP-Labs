﻿using System;

namespace Inheritance
{
    enum breed {golden, cairm, dandie, shetland, doberman, lab};

    class Mammal 
    {
        private
            int its_age;  
            int its_weight;

        public int Age 
        {
            get => its_age;
            set => its_age = value;
        }

        public int Weight
        {
            get => its_weight;
            set => its_weight = value;
        }

        public Mammal() : this(2, 5)
        {}
        
        public Mammal(int its_age, int its_weight)
        {
            this.Age = its_age;
            this.Weight = its_weight;
        }

        public void speak()
        {
            Console.WriteLine("mammal sound");
        }

        public void sleep(string sleep_sounds)
        {
            if (sleep_sounds == "")
            {
                Console.WriteLine("mammal sleep: hrrr");
            } 
            
            else 
            {
                Console.WriteLine($"mammal sleep: {sleep_sounds}");
            }
            
        }
        ~Mammal()
        {}
    }

    class Dog : Mammal
    {
        private breed its_breed;
        public breed aBreed
        {
            get => its_breed;
            set => its_breed = value;
        }

        public void wag_tail()
        {
            Console.WriteLine("tail wadding");
        }

        public void beg_for_food()
        {
            Console.WriteLine("begging for food");
        }

        public Dog(breed aBreed, double its_age, double its_weight) 
            : base((int)its_age, (int)its_weight)
        {
            this.aBreed = aBreed;
        }

        public Dog(breed aBreed, int its_age, int its_weight) 
            : base(its_age, its_weight)
        {
            this.aBreed = aBreed;
        }

        public Dog(breed aBreed)
        {
            this.aBreed = aBreed;
        }

        public Dog() 
        {
            aBreed = breed.golden;
        }

        ~Dog()
        {}

    }
    
    class Program
    {
        static void Main(string[] args)
        {
            Dog Fido = new Dog();
            Dog Charley = new Dog(breed.lab);
            Dog Mars = new Dog(breed.dandie, 3, 8);
            Dog Bumer = new Dog(breed.doberman, 2.0, 3.435);
            
            // Fido buddy
            Fido.speak();
            Fido.beg_for_food();
            Console.WriteLine($"Fido's Age: {Fido.Age}, Weight: {Fido.Weight}");
            Console.WriteLine("=========================================================");
            
            //Charley buddy
            Charley.sleep("frfrfrfrfrfr");
            Console.WriteLine($"Charley's Age: {Charley.Age}, Weight: {Charley.Weight}");
            Console.WriteLine("=========================================================");
            
            //Mars buddy
            Mars.beg_for_food();
            Mars.wag_tail();
            Console.WriteLine($"Mars Age: {Mars.Age}, Weight: {Mars.Weight}");
            Console.WriteLine("=========================================================");
            
            //Bumer buddy
            Bumer.speak();
            Bumer.wag_tail();
            Console.WriteLine($"Bumer's Age: {Bumer.Age}, Weight: {Bumer.Weight}");
            Console.WriteLine("=========================================================");

        }
    }
}
