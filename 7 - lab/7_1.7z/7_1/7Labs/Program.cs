﻿using System;

namespace _7Labs
{
    class Complex
    {
        private double realPart;
        private double imaginaryPart;

        public Complex(double realPart, double imaginaryPart)
        {
            this.realPart = realPart;
            this.imaginaryPart = imaginaryPart;
        }
    
        public static Complex Summarizing(Complex first, Complex second)
        {
            return new Complex((first.realPart + second.imaginaryPart), (first.imaginaryPart + second.imaginaryPart));
        }

        public static Complex Subtraction(Complex first, Complex second)
        {
            return new Complex((first.realPart - second.imaginaryPart), (first.imaginaryPart - second.imaginaryPart));
        }

        public static Complex Multiplication(Complex first, Complex second)
        {
            return new Complex((first.realPart * second.realPart) - (first.imaginaryPart * second.imaginaryPart), 
                                ((first.realPart * second.imaginaryPart) + (first.imaginaryPart * second.realPart)));
        }

        public override string ToString()
        {
            return ($"({Math.Round(realPart, 2)}; {Math.Round(imaginaryPart, 2)})");
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Complex firstNumber = new Complex(2, 3);
            Complex secondNumber = new Complex(-1, 1);


            Console.WriteLine("Complex number A: " + firstNumber);
            Console.WriteLine("Complex number B: " + secondNumber);
            Console.WriteLine();

            Console.WriteLine("A + B: " + Complex.Summarizing(firstNumber, secondNumber));
            Console.WriteLine("A - B: " + Complex.Subtraction(firstNumber, secondNumber));
            Console.WriteLine("B - A: " + Complex.Subtraction(secondNumber, firstNumber));
            Console.WriteLine("A * B: " + Complex.Multiplication(firstNumber, secondNumber));
            Console.WriteLine();
        }
    }
}
