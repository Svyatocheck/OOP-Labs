﻿using System;

namespace _7_4Lab
{
    class Program
    { 
        static void Main(string[] args)
        {
            DateManager date_1 = new DateManager();
            DateManager date_2 = new DateManager(26, 06, 2001);
            DateManager date_3 = new DateManager(-15, -08, -2014);

            Console.WriteLine("Here are some dates: ");
            Console.WriteLine(date_1);
            Console.WriteLine(date_2);
            Console.WriteLine(date_3);
            Console.WriteLine();

            Console.WriteLine("Demonstration of postfix increment: ");
            date_1++;
            date_2++;
            date_3++;
            Console.WriteLine(date_1);
            Console.WriteLine(date_2);
            Console.WriteLine(date_3);
            Console.WriteLine();

            Console.WriteLine("Demonstration of postfix decrement: ");
            date_1--;
            date_2--;
            date_3--;
            Console.WriteLine(date_1);
            Console.WriteLine(date_2);
            Console.WriteLine(date_3);
            Console.WriteLine();

            Console.WriteLine("Demonstration of addition: ");
            date_1 += 2;
            date_2 += 2;
            date_3 += 2;
            Console.WriteLine(date_1);
            Console.WriteLine(date_2);
            Console.WriteLine(date_3);
            Console.WriteLine();

            Console.WriteLine("Demonstration of prefix increment: ");
            ++date_1;
            ++date_2;
            ++date_3;
            Console.WriteLine(date_1);
            Console.WriteLine(date_2);
            Console.WriteLine(date_3);
            Console.WriteLine();

            Console.WriteLine("Demonstration of prefix decrement: ");
            --date_1;
            --date_2;
            --date_3;
            Console.WriteLine(date_1);
            Console.WriteLine(date_2);
            Console.WriteLine(date_3);
            Console.WriteLine();
        }
    }
}
