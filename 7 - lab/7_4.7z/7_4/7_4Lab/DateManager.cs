﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7_4Lab
{
    using System;

   class DateManager
    {
        private int Day;
        private int Month;
        private int Year;

        public DateManager(int day, int month, int year)
        {
            Day = (day <= 31 && day > 0) ? day : 31;
            Month = (month <= 12 && month > 0) ? month : 12;
            Year = (year >= 0) ? year : 2000;
        }

        public DateManager()
        {
            Day = DateTime.Today.Day;
            Month = DateTime.Today.Month;
            Year = DateTime.Today.Year;
        }

        public static DateManager operator ++(DateManager date)
        {
            int newDay, newMonth, newYear;

            newDay = date.Day;
            newMonth = date.Month;
            newYear = date.Year;

            int counter = getDaysNumber(newYear, newMonth);

            if (newDay == counter)
            {
                newDay = 1;
                newMonth += 1;

            } else {
                newDay += 1;
            }
            
            if (newMonth == 13)
            {
                newMonth = 1;
                newYear += 1;
            }

            return new DateManager(newDay, newMonth, newYear);
        }

        public static DateManager operator --(DateManager date)
        {
            int resultDay, resultMonth, resultYear;

            resultDay = date.Day - 1;
            resultMonth = date.Month;
            resultYear = date.Year;

            if (resultDay == 0)
            {
                resultMonth -= 1;
                
                if (resultMonth == 0)
                {
                    resultYear -= 1;
                }

                resultDay = getDaysNumber(resultYear, resultMonth);
            }

            return new DateManager(resultDay, resultMonth, resultYear);
        }

        public static DateManager operator +(DateManager date, int number)
        {
            int resultDay, resultMonth, resultYear;
            
            resultDay = date.Day;
            resultMonth = date.Month;
            resultYear = date.Year;
            
            int counter = getDaysNumber(resultYear, resultMonth);

            if (number != 0)
            {
                if ((resultDay + number) < counter)
                {
                    resultDay += number;
                    //number = 0;
                }

                else
                {
                    number -= counter - resultDay + 1;
                    resultDay = 1 + number;
                    resultMonth += 1;
                    
                    //Console.WriteLine(number);
                    if (resultMonth == 13)
                    {
                        resultMonth = 1;
                        resultYear += 1;
                    }
                }
            }

            return new DateManager(resultDay, resultMonth, resultYear);
        }
        
        private int getDaysNumber()
        {
            int days = DateTime.DaysInMonth(this.Year, this.Month);
            return days;
        }
        public static int getDaysNumber(int year, int month)
        {
            int days = DateTime.DaysInMonth(year, month);
            return days;
        }

        public override string ToString()
        {
            return Day + "/" + Month + "/" + Year;
        }
    }
}
