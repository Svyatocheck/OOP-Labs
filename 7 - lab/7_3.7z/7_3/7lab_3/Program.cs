﻿using System;

namespace _7lab_3
{
    public class Rational
    {
        private int numerator;
        private int denominator;

        public Rational(int n, int m)
        {
            this.numerator = n;
            this.denominator = m;
            Normalization();
        }

        public Rational() : this(2, 4)
        { }

        public void Addition(Rational other)
        {
            this.numerator = (this.numerator * other.denominator) + (other.numerator * this.denominator);
            this.denominator = this.denominator * other.denominator;
        }

        public void Subtraction(Rational other)
        {
            this.numerator = (this.numerator * other.denominator) - (other.numerator * this.denominator);
            this.denominator = this.denominator * other.denominator;
            Normalization();
        }

        public void Multiplication(Rational other)
        {
            this.numerator *= other.numerator;
            this.denominator *= other.denominator;
            Normalization();
        }

        public void Division(Rational other)
        {
            this.numerator *= other.denominator;
            this.denominator *= other.numerator;
            Normalization();
        }

        static public Rational Addition(Rational first, Rational second)
        {
            int sumNumerator = (first.numerator * second.denominator) + (second.numerator * first.denominator);
            int sumDenominator = first.denominator * second.denominator;
            return new Rational(sumNumerator, sumDenominator);
        }

        static public Rational Subtraction(Rational first, Rational second)
        {
            int subNumerator = (first.numerator * second.denominator) - (second.numerator * first.denominator);
            int subDenominator = first.denominator * second.denominator;
            return new Rational(subNumerator, subDenominator);
        }

        static public Rational Multiplication(Rational first, Rational second)
        {
            int multNumerator = first.numerator * second.numerator;
            int multDenominator = first.denominator * second.denominator;
            return new Rational(multNumerator, multDenominator);
        }

        static public Rational Division(Rational first, Rational second)
        {
            int divNumerator = first.numerator * second.denominator;
            int divDenominator = first.denominator * second.numerator;
            return new Rational(divNumerator, divDenominator);
        }

        public double getDouble()
        {
            double a = numerator;
            double b = denominator;
            double division = a / b;
            return Math.Round(division, 2);
        }

        public string getDoubleString()
        {
            return Convert.ToString(getDouble());
        }

        public override string ToString()
        {
            return $"({numerator} / {denominator})";
        }

        private void Normalization()
        {
            int gcd = Gcd(Math.Abs(numerator), Math.Abs(denominator));
            while (gcd != 1)
            {
                numerator /= gcd;
                denominator /= gcd;
                gcd = Gcd(Math.Abs(numerator), Math.Abs(denominator));
            }
        }

        private int Gcd(int a, int b)
        {
            if (a == 0)
            {
                return b;
            }
            else
            {
                var min = Min(a, b);
                var max = Max(a, b);
                return Gcd(max % min, min);
            }
        }

        private int Min(int a, int b)
        {
            return a < b ? a : b;
        }

        private int Max(int a, int b)
        {
            return a > b ? a : b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();

            Rational a = new Rational(2, 7);
            Rational b = new Rational(-5, 10);
            Rational c = new Rational(-1, -6);

            Console.WriteLine("===== Build in func =====");
            Console.WriteLine( a + ", in Double: " + a.getDoubleString());
            Console.WriteLine( b + ", in Double: " + b.getDoubleString());
            Console.WriteLine( c + ", in Double: " + c.getDoubleString());
            Console.WriteLine();

            Console.Write(a + " + " + b + " = ");
            a.Addition(b);
            Console.Write(a + ",  in Double: " + a.getDoubleString());
            Console.WriteLine();

            Console.Write(a + " - " + b + " = ");
            a.Subtraction(b);
            Console.Write(a + ",  in Double: " + a.getDoubleString());
            Console.WriteLine();

            Console.Write(c + " * " + b + " = ");
            c.Multiplication(b);
            Console.Write(c + ",  in Double: " + c.getDoubleString());
            Console.WriteLine();

            Console.Write(a + " / " + c + " = ");
            a.Division(c);
            Console.Write(a + ",  in Double: " + a.getDoubleString());
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine("===== Static func =====");
            Console.WriteLine(a + " + " + c + " = " + Rational.Addition(a, c));
            Console.WriteLine(b + " - " + a + " = " + Rational.Subtraction(b, a));
            Console.WriteLine(c + " * " + b + " = " + Rational.Multiplication(c, b));
            Console.WriteLine(b + " / " + a + " = " + Rational.Division(b, a));
        }
    }
}
