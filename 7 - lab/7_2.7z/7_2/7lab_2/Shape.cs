﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7lab_2
{
    public abstract class Shape
    {
        public abstract float Perimeter();
        public abstract float Square(); 
        public abstract void PrintOut();
    }
}
