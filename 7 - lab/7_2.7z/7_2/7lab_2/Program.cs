﻿using System;

namespace _7lab_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Shapes
            Console.WriteLine("============= Shapes ==========");

            Circle circle = new Circle(12);
            Rectangle rectangle = new Rectangle(13, 8);
            Triangle triangle = new Triangle(3, 4, 5);

            circle.PrintOut();
            Console.WriteLine("Square: " + circle.Square());
            Console.WriteLine("Perimeter: " + circle.Perimeter());
            Console.WriteLine();

            rectangle.PrintOut();
            Console.WriteLine("Square: " + rectangle.Square());
            Console.WriteLine("Perimeter: " + rectangle.Perimeter());
            Console.WriteLine();

            triangle.PrintOut();
            Console.WriteLine("Square: " + triangle.Square());
            Console.WriteLine("Perimeter: " + triangle.Perimeter());
            Console.WriteLine();

            // Animals
            Console.WriteLine("============= Animals ==========");
            Dog dog = new Dog("Demon");
            Platypus platypus = new Platypus("Perry");

            dog.PrintOut();
            string isDog = (dog.Procreation()) ? "Procreation: viviparous" : "";
            Console.WriteLine(isDog);
            Console.WriteLine();

            platypus.PrintOut();
            string isPlatypus = (platypus.Procreation()) ? "" : "Procreation: egg - bearing";
            Console.WriteLine(isPlatypus);
            Console.WriteLine();
        }
    }
}
