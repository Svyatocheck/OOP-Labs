﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7lab_2
{
    public abstract class Animal
    { 
        public abstract bool Procreation();
        public abstract void PrintOut();

    }
}
