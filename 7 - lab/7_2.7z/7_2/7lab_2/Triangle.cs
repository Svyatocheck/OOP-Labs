﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7lab_2
{
    class Triangle : Shape
    {
        private float a;    // The first face
        private float b;    // The second face
        private float c;    // The third face

        public Triangle(float a, float b, float c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public override float Perimeter()
        {
            return (float)(a + b + c);
        }

        public override float Square()
        {
            float p = (float)(Perimeter() / 2);
            return (float)Math.Sqrt(p * (p - this.a) * (p - this.b) * (p - this.c));
        }

        public override void PrintOut()
        {
            Console.WriteLine("This is a Triangle (Base on Shape), a = " + this.a + " b = " + this.b + " c = " + this.c);
        }

    }
}
