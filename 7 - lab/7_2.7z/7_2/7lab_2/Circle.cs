﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7lab_2
{
    class Circle : Shape
    {
        private float radius;

        public Circle(float radius)
        {
            this.radius = radius;
        }

        public override float Perimeter()
        {
            return (float)(2 * Math.PI * radius);
        }

        public override float Square()
        {
            return (float)(Math.PI * radius * radius);
        }

        public override void PrintOut()
        {
            Console.WriteLine("This is a Circle (Base on Shape), Radius: " + this.radius);
        }

    }
}
