﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7lab_2
{
    class Rectangle : Shape
    {
        private float width;
        private float height;

        public Rectangle(float w, float h)
        {
            this.width = w;
            this.height = h;
        }

        public override float Perimeter()
        {
            return (float)((this.width + this.height) * 2);
        }

        public override float Square()
        {
            return (float)(this.width * this.height);
        }

        public override void PrintOut()
        {
            Console.WriteLine("This is a Rectangle (Base on Shape), Width: " + this.width + " Heigh: " + this.height);
        }
    }
}
