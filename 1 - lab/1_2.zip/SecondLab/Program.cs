﻿using System;

namespace NewNamespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rectangle = new Rectangle(100, 20, 50, 80);
            int area = rectangle.GetArea();

            Console.WriteLine("Area: " + area);
            Console.WriteLine("Upper Left X Coordinate: " + rectangle.UpperLeftField.PointX);

        }
    }
}
