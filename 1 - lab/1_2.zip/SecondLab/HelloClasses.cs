﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewNamespace
{
    class Point
    {
        private int itsX;
        private int itsY;

        public int PointX
        {
            get { return itsX; }
            set { itsX = value;}
        }

        public int PointY
        {
            get { return itsY; }
            set { itsY = value;}
        }

    }

    class Rectangle : Point
    {
        // Simple points
        private int itsTop;
        private int itsLeft;
        private int itsBottom;
        private int itsRight;

        public int TopPoint
        {
            get { return itsTop; }
            set { itsTop = value; }
        }

        public int LeftPoint
        {
            get { return itsLeft; }
            set { itsLeft = value; }
        }

        public int BottomPoint
        {
            get { return itsBottom; }
            set { itsBottom = value; }
        }

        public int RightPoint
        {
            get { return itsRight; }
            set { itsRight = value; }
        }

        // Elite points
        private Point itsUpperLeft = new Point();
        private Point itsUpperRight = new Point();
        private Point itsLowerRight = new Point();
        private Point itsLowerLeft = new Point();

        public Point UpperLeftField
        {
            get { return itsUpperLeft; }
            set { itsUpperLeft = value; }
        }

        public Point UpperRightField
        {
            get { return itsUpperRight; }
            set { itsUpperRight = value; }
        }

        public Point LowerRightField
        {
            get { return itsLowerRight; }
            set { itsLowerRight = value; }
        }

        public Point LowerLeftField
        {
            get { return itsLowerLeft; }
            set { itsLowerLeft = value; }
        }

        // Last step
        public Rectangle(int top, int left, int bottom, int right)
        {
            TopPoint = top;
            LeftPoint = left;
            BottomPoint = bottom;
            RightPoint = right;

            itsUpperLeft.PointX = left;
            itsUpperLeft.PointY = top;

            itsUpperRight.PointX = right;
            itsUpperRight.PointY = top;

            itsLowerLeft.PointX = left;
            itsLowerLeft.PointY = bottom;

            itsLowerRight.PointX = right;
            itsLowerRight.PointY = bottom;
        }

        // Some functions
        public int GetArea()
        {
            int Width = itsRight - itsLeft;
            int Height = itsTop = itsBottom;

            return (Width * Height);
        }
    }
}
