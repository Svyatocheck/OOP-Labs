﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_6
{
    class Square : Rectangle
    {
        public Square (int len) : base(len, len) {}
        
        public Square(int len, int width) : base(len, width)
        {
            if(get_lenght() != get_width())
            {
                Console.WriteLine("Not a square");
            }
        }
        
        public override long get_perim()
        {
            return Convert.ToInt64(4*get_lenght());
        }
    }
}
