﻿using System;

namespace Task_6
{
    class Circle : Shape
    {
        private int its_radius;
        public Circle(int radius)
        {
            its_radius = radius;
        }

        public override long get_area()
        {
            return Convert.ToInt64(3.1415926*its_radius*its_radius);
        }

        public override long get_perim()
        {
            return Convert.ToInt64(2*3.1415926*its_radius);
        }

        public override void draw()
        {
            Console.WriteLine("Circle draw here");
        }
    }
}
