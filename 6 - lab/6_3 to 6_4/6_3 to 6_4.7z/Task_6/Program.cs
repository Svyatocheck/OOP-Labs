﻿using System;

namespace Task_6
{
    class Program
    {
        static void Main(string[] args)
        {
            // Task 3
            // C# не поддерживает множественное наследование
            // Надо почитать, почему

            // Task 4
            Console.WriteLine();
            Console.WriteLine("Task 4");

            bool fquit = false;
            Shape sp;
            while (!fquit)
            {
                Console.WriteLine("(1) - circle, (2) - rectangle, (3) - square, (4) - quit:");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 4:
                        fquit = true;
                        break;
                    case 1:
                        sp = new Circle(4);
                        sp.draw();
                        break;
                    case 2:
                        sp = new Rectangle(4, 6);
                        sp.draw();
                        break;
                    case 3:
                        sp = new Square(5);
                        sp.draw();
                        break;
                    default:
                        Console.WriteLine("Enter a number between 1 and 4\nContinue");
                        break;
                }

                if (!fquit)
                {
                    sp = new Shape();
                    sp.draw();
                }
                Console.WriteLine();
            }
        }
    }
}
