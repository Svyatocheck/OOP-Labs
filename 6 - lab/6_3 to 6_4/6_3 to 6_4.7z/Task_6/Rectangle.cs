﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_6
{
    class Rectangle : Shape
    {
        private int its_width;
        private int its_lenght;
        public Rectangle(int len, int width)
        {
            its_lenght = len;
            its_width = width;
        }

        public override long get_area()
        {
            return Convert.ToInt64(its_lenght*its_width);
        }
        public override long get_perim()
        {
            return Convert.ToInt64(2 * (its_lenght + its_width));
        }
        public virtual int get_lenght() { return its_lenght; }
        public virtual int get_width() { return its_width; }
        public override void draw()
        {
            Console.WriteLine("Rectangle");
            for(int i = 1; i < its_lenght; i++)
            {
                for(int j = 1; j < its_width; j++)
                {
                    Console.Write("x");
                }
                Console.WriteLine();
            }
        }
    }
}
