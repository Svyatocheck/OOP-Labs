﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_6
{
    class Shape
    {
        public Shape() {}
        public virtual long get_area() { return -1; }
        public virtual long get_perim() { return -1; }
        public virtual void draw() {}
    }
}
