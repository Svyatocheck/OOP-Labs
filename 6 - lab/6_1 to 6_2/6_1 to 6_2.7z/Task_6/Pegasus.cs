﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_6
{
    class Pegasus : Horse
    {
        public override void Fly()
        {
            Console.WriteLine("I can fly!\n");
        }
    }
}
