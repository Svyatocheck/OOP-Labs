﻿using System;

namespace Task_6
{
    class Program
    {
        const int number_of_horses = 5;
        // http://programming-lang.com/ru/comp_programming/liberti/0/j353.html
        
        static void Main(string[] args)
        {
            // Task 1
            Console.WriteLine("Task 1");
            Horse[] ranch = new Horse[number_of_horses];
            Horse p_horse;
            int choice;

            for (int i = 0; i < number_of_horses; i++)
            {
                Console.WriteLine("(1) - horse, (2) - pegas");
                try
                {
                    choice = Convert.ToInt32(Console.ReadLine());
                    
                    if (choice == 2)
                    {
                        p_horse = new Pegasus();
                    }
                    else
                    {
                        p_horse = new Horse();
                    }
                    ranch[i] = p_horse;
                }
                catch (FormatException e) { return; }
            }

            for (int i = 0; i < number_of_horses; i++)
            {
                ranch[i].Fly();
            }

            // Task 2
            Console.WriteLine();
            Console.WriteLine("Task 2");
            for (int i = 0; i < number_of_horses; i++)
            {
                Pegasus p_peg = ranch[i] as Pegasus;
                if (p_peg != null)
                {
                    p_peg.Fly();
                }
                else
                {
                    Console.WriteLine("Just a horse\n");
                }

            }
        }
    }
}
