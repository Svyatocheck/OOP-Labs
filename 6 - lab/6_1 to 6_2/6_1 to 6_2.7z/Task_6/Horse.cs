﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_6
{
    class Horse
    {
        private int its_age;

        public void gallop()
        {
            Console.WriteLine("Galloping...\n");
        }

        // может быть переопределен
        // в одном в одном или нескольктх производных классах
        public virtual void Fly()
        {
            Console.WriteLine("Horses can't fly.\n");
        }
    }
}
