﻿using System;


namespace NewNamespace
{
    class Lets_do_some_math
    {
        // Возврат нескольких значений
        public (double coub_number, double square_number) NewFunction (int number)
        {
            return (Math.Pow(number, 2), Math.Pow(number, 3));
        }
    }
}
