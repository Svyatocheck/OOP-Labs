﻿using System;
using  Task = NewNamespace.Lets_do_some_math;

namespace NewNamespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Task check = new Task();

            // Демонстрация возврата нескольких значений
            var (coub_number, square_number) = check.NewFunction(12);
            Console.WriteLine("Values are: {0}, {1}", coub_number, square_number);

        }
    }
}
