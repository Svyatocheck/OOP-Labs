﻿namespace NewNamespace
{
    class Cat
    {
        private int its_age;
        private int its_weight;

        public int Age
        {
            get { return its_age; }
            set { its_age = value; }
        }
        public int Weight
        {
            get { return its_weight; }
            set { its_weight = value; }
        }

        public Cat(int Age, int Weight)
        {
            this.Age = Age;
            this.Weight = Weight;
        }

        ~Cat()
        {}
    }
}
