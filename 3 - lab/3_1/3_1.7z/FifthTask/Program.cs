﻿using System;
using Kitty = NewNamespace.Cat;
namespace NewNamespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Kitty Misha = new Kitty(1, 5);
            Console.WriteLine($"Misha is {Misha.Age} years old and his weight is {Misha.Weight}");
            
            Misha.Age = 5;
            Misha.Weight = 12;
            Console.WriteLine($"Misha is {Misha.Age} years old and his weight is {Misha.Weight}");
        }
    }

}
