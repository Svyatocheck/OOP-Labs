﻿using System;

namespace NewNamespace
{
    class Cat
    {
        private int its_age;

        public int Age
        {
            get { return its_age; }
            set { its_age = value; }
        }

        public Cat()
        {
            Console.WriteLine("Cat constructor");
            this.Age = 1;
        }

        public Cat(Cat cat)
        {
            Console.WriteLine("Cat copy constructor");
        }

        ~Cat()
        {
            Console.WriteLine("Destructor");
        }

    }
}
