﻿using System;
using SimpleCat = NewNamespace.Cat;

namespace NewNamespace
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("make a cat");
            
            SimpleCat frisky = new SimpleCat();
            frisky.Age = 5;
            Console.WriteLine($"Frisky is {frisky.Age} years old");
            
            Console.WriteLine("calling f1");
            F1(frisky);
            
            Console.WriteLine("calling f2");
            F2(frisky);

            Console.WriteLine($"Frisky is {frisky.Age} years old");
        }

        public static SimpleCat F1(SimpleCat cat)
        {
            Console.WriteLine("f1 returning");
            return cat;
        }

        public static SimpleCat F2(SimpleCat cat)
        {
            Console.WriteLine("f2 returning");
            cat.Age = 7;
            Console.WriteLine("frisky is now {0} years old", cat.Age);
            return cat;
        }
    }
}
