﻿using System;

namespace _4_2
{
    class Rectangle
    {
        private
            int its_width;
            int its_height;

        public int Width
        {
            get => its_width;
            set => its_width = value;
        }

        public int Height
        {
            get => its_height;
            set => its_height = value;
        }

        public Rectangle() : this(5, 6)
        { }

        public Rectangle(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect = new Rectangle();
            Console.WriteLine($"rect width {rect.Width}\nrect height{rect.Height}");

            int a, b;
            Console.WriteLine("enter a width:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter a length:");
            b = Convert.ToInt32(Console.ReadLine());

            Rectangle rect2 = new Rectangle(a, b);
            Console.WriteLine($"rect width {rect2.Width}\nrect height{rect2.Height}");
        }
    }
}
