﻿using System;

namespace _4_3
{
    class counter
    {
        private
            int its_value;

        public int Value
        {
            get => its_value;
            set => its_value = value;
        }

        ~counter()
        {
            ;
        }

        public counter()
        {
            Value = 0;
        }

        public counter(int init)
        {
            Value = init;
        }

        public void increment()
        {
            ++ Value;
        }

        public static counter operator ++(counter c1)
        {
            return new counter { Value = ++ c1.Value };
        }

        public static counter operator +(counter c1, counter c2)
        {
            return new counter { Value = c1.Value + c2.Value };
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Task 4.3
            counter i = new counter(); 
            Console.Write($"value of counter is {i.Value}\n");
            i.increment();
            Console.Write($"value of counter is {i.Value}\n");
            i++;
            Console.Write($"value of counter is {i.Value}\n");

            // Task: 4.4
            Console.WriteLine("Task: 4.4");
            counter i_2 = new counter();
            Console.WriteLine($"value of counter is {i_2.Value}");
            i_2++;
            Console.WriteLine($"value of counter is {i_2.Value}");
            ++i_2;
            Console.WriteLine($"value of counter is {i_2.Value}");

            counter a = ++i;
            Console.WriteLine($"value of a is {a.Value}");
            Console.WriteLine($"value of counter is {i_2.Value}");

            a = i++;
            Console.WriteLine($"value of a is {a.Value}");
            Console.WriteLine($"value of counter is {i_2.Value}");


            // Task: 4.5
            Console.WriteLine("Task: 4.5");
            int aInt = 2;
            counter var1 = new counter(aInt);
            counter var2 = new counter(5);
            counter var3 = var1 + var2;
            Console.WriteLine($"var1 = {var1.Value}");
            Console.WriteLine($"var2 = {var2.Value}");
            Console.WriteLine($"var3 = {var3.Value}");
        }
    }
}
