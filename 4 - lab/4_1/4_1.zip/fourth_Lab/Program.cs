﻿using System;

namespace fourth_Lab
{
    class Rectangle
    {
        private
            int its_width;
            int its_height;

        public int Width
        {
            get => its_width;
            set => its_width = value;
        }
        
        public int Height
        {
            get => its_height;
            set => its_height = value;
        }

        public Rectangle(int width, int height)
        {
            Width = width;
            Height = height;
        }

        public void draw()
        {
            draw(Width, Height);     
        }

        public void draw(int width, int height)
        {
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j ++)
                {
                    Console.Write("*");
                }

                Console.Write("\n");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect = new Rectangle(30, 5);
            Console.WriteLine("draw");
            rect.draw();

            Console.WriteLine("draw\n");
            rect.draw(10, 4);
        }
    }
}
