﻿// SimpleCat class
namespace NewNamespace
{
    class SimpleCat
    {
        private int its_age;

        public int Age
        {
            get { return its_age;  }
            set { its_age = value; }
        }


        public SimpleCat(int its_age)
        {
            Age = its_age;
        }

        ~SimpleCat()
        { }
    }
}
