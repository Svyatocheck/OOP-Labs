﻿using System;

namespace NewNamespace
{
    class Program
    {
        static void Main(string[] args)
        {
            SimpleCat Misha = new SimpleCat(2);
            Console.WriteLine($"Misha is {Misha.Age} years old");

            Misha.Age = 5;
            Console.WriteLine($"Misha is {Misha.Age} years old");
        }
    }
}
