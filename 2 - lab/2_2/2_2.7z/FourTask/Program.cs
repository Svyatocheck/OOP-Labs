﻿using System;

namespace NewNamespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Cat Misha = new Cat(1, 5);
            Console.WriteLine($"Misha is {Misha.Age} years old and his weight is {Misha.Weight}");
            
            Misha.Age = 5;
            Misha.Weight = 12;
            Console.WriteLine($"Misha is {Misha.Age} years old and his weight is {Misha.Weight}");
            
            // Я читал, что в C# встроен сборщик мусора и то, что работает в С++ не тут организовать не получится.

        }
    }
}
